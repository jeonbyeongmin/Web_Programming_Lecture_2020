<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    // validation check

    $id = $pw = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $id = test_input($_POST["id"]);
      $pw = test_input($_POST["pw"]);
    }
    function test_input($data){
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    $fp = fopen("./data/person.json", "r") or die("file not exist");
    $check = 0;
    while(!feof($fp)){
      $json = fgets($fp);
      $data = json_decode($json, true);
      if ($data['id'] == $id && $data['pw'] == $pw) {
        $check = 1;
        break;
      }
    }
    if ($check === 1) {
      session_start();
      $_SESSION['id'] = $id;
      $_SESSION['pw'] = $pw;
      echo $id . "님 로그인이 되었습니다.<br><br>";
      echo "
        <form action = \"change_pw.html\" method=\"post\">
          <input type=\"submit\" value=\"비밀번호 변경\">
        </form>";
    } else {
      echo "입력하신 id가 존재하지 않거나 패스워드가 틀립니다.";
    }


     ?>
  </body>
</html>
