
document.getElementById("resetPWBT").addEventListener("click", function(){
  document.getElementById("changePW").value = null;
})
