<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php

    // validation check
    $id = $pw = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $id = test_input($_POST["id"]);
      $pw = test_input($_POST["pw"]);
    }
    function test_input($data){
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    // json file open
    $fp = fopen("./data/person.json", "a+") or die("파일 열기 실패");
    $check = 1;

    // already exist id check
    while(!feof($fp)){
      $json = fgets($fp);
      $data = json_decode($json, true);
      if ($data['id'] == $id)  {
        echo "이미 아이디가 존재합니다.";
        $check = 0;
        break;
      }
    }

    // write the json encoded string in json file
    if ($check == 1) {
      if (!isset($myObj))
        $myObj = new stdClass();
      $myObj->id=$id;
      $myObj->pw=$pw;
      $myJSON = json_encode($myObj);

      fwrite($fp, $myJSON);
      fwrite($fp, "\n");
      echo "회원 가입이 완료되었습니다.";
    }

    fclose($fp);
     ?>
  </body>
</html>
