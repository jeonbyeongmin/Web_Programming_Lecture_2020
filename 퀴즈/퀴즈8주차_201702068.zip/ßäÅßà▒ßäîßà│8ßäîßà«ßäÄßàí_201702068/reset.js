
//초기화 버튼을 클릭할 때, 아이디와 패스워드 텍스트 필드가 초기화 되는 함수.

document.getElementById("resetBT").addEventListener("click", function(){
  document.getElementById("inputID").value = null;
  document.getElementById("inputPW").value = null;
})
