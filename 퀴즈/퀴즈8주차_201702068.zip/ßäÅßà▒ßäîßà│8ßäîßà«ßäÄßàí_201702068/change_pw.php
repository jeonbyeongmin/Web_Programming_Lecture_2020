<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    //session start
    session_start();

    // validation check
    $pw = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $pw = test_input($_POST["changePW"]);
    }
    function test_input($data){
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    $fp = fopen("./data/person.json", "r") or die("fail");
    $tempArr = array();
    while (!feof($fp)) {
      $json = fgets($fp);
      $data = json_decode($json, true);

      if ($data['id'] == $_SESSION['id']) {
        $data['pw'] = $pw;
        array_push($tempArr, $data);
      } else {
        if ($data['id'] == null) {
          continue;
        } else {
          array_push($tempArr, $data);
        }
      }
    }

    $fp = fopen("data/person.json", "w");
    foreach ($tempArr as $key => $value) {
      if (!isset($myObj))
        $myObj = new stdClass();
      $myObj->id=$value['id'];
      $myObj->pw=$value['pw'];
      $myJSON = json_encode($myObj);
      fwrite($fp, $myJSON);
      fwrite($fp, "\n");
    }
    echo "비밀번호 변경이 성공적으로 완료되었습니다.";
    fclose($fp);
     ?>
  </body>
</html>
