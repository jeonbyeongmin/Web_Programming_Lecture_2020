
$(document).ready(function(){

    // 저장 버튼을 클릭하였을 때
    $("#storeButton").click(function(){

        var dataObj = new Object();
        dataObj.title = $("#title").val();
        dataObj.content = $("#content").val();
    
        var jsonData = JSON.stringify(dataObj);
        alert(jsonData);
        
        $.ajax({
            url:'store.php',
            type:'POST',
            data: jsonData,
            success:function(){
                alert("저장되었습니다.");
            },
            error:function(){
                alert("저장되지 않았습니다.");
            } 
        })
    })

    // 키를 누르고 다시 올라왔을 때
    $("#keyword").keyup(function(){
        var dataObj = new Object();
        dataObj.key = $(this).val();

        var jsonData = JSON.stringify(dataObj);
        alert(jsonData);
        
        $.ajax({
            url: 'search.php',
            type: 'POST',
            data: jsonData,
            dataType: 'json',
            success:function(data){
                var str = ''
                var tempData = JSON.stringify(data);
                alert(tempData);
                for(let i = 0; i < data.length; i++){
                    str += '<li>'+data[i]+'</li>';
                }
                $('#list').html(str);
            },
            
        })

    })
})
