<?php 

$PATH = "./data/data.json";
$json = "";

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function searchData(){

    global $json;
    global $PATH;

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // vaildation check
    $key = test_input($data['key']);

    $fp = fopen($PATH, "r") or die("file not exist");

    $tempArray = array();
    while(!feof($fp)){
        $fileJson = fgets($fp);
        $fileData = json_decode($fileJson, true);

        if(stristr($fileData['title'], $key)){
            array_push($tempArray, $fileData['title']);
        }
    }
    echo json_encode($tempArray);
    
}

searchData();

?>
