<?php 

$PATH = "./data/data.json";
$json = "";

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function storeData(){

    global $json;
    global $PATH;

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // vaildation check
    $title = test_input($data['title']);
    $content = test_input($data['content']);

    if(!isset($myObj)){
        $myObj = new stdClass();
    }
    $myObj->title = $title;
    $myObj->content = $content;
    $myJSON = json_encode($myObj);

    $fp = fopen($PATH, "a+") or die("file not exist");
    fwrite($fp, $myJSON . "\n");
    
}

storeData();

?>