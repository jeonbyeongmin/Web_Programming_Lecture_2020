


document.getElementById("submitButton").addEventListener("click", clickbutton);

function clickbutton() {
    if(confirm("이벤트에 참여하시겠습니까?") === true){
        var name = prompt("성함을 입력해주세요.");
        if(name === ""){
            alert("다시 참여해주세요.");

        } 
        else if(name === null){
            alert("이벤트 참여를 취소했습니다.");
        } else {
            document.getElementById("outputText").innerHTML = name + "님 이벤트에 참가해주셔서 감사합니다."
        }
    } else {
        alert("이벤트 참여를 취소했습니다.");
    }
}

