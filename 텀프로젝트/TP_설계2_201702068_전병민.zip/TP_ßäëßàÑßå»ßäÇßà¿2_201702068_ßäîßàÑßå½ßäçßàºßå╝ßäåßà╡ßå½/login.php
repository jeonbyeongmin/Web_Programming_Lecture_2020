<?php

/* 로그인 페이지에서 로그인 버튼을 눌렀을 때 서버와의 통신과 관련된 PHP */

$PATH = "./data/id.json"; // id json 데이터 저장 경로
session_start(); // 사용자 id를 담기 위해 session start

// validation check function
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function login(){

    global $PATH;
    $id = $pw = "";
    
    if (isset($_POST["id"]) && isset($_POST["pw"])) { // POST 형식으로 넘어왔을 때 validation check
        $id = test_input($_POST["id"]);
        $pw = test_input($_POST["pw"]);
    } else {
        echo("데이터 전송이 원할하지 않습니다."); // POST에 데이터가 존재하지 않을 경우 클라이언트에 에러 메시지 전송
        exit;
    }

    if(is_file($PATH)){ 

        $json = file_get_contents($PATH);
        $jsonArr = json_decode($json, true); // json 형태의 데이터를 가지고 있는 배열이 생성됨
        $check = false;
        
        for ($i=0; $i < sizeof($jsonArr); $i++) { 
            if($jsonArr[$i]["id"] === $id && $jsonArr[$i]["pw"] === $pw){
                $check = true; // id와 pw가 일치 
            break;
            }
        }

        if($check){ // id와 pw가 일치하는 데이터가 있을 때
            $_SESSION["id"] = $id; // session에 id 정보를 저장
            echo "${id}님 로그인  되었습니다.";
            exit;
        } else { // 일치하는 데이터가 없을 때
            echo "입력한 id가 존재하지 않거나 패스워드가 틀립니다.";
            exit;
        }
    } else {
        echo "입력한 id가 존재하지 않거나 패스워드가 틀립니다."; // 파일이 없을 경우 입력한 id가 존재하지 않기 때문에 에러 메시지 전송
        exit;
    }

}

login();

?>