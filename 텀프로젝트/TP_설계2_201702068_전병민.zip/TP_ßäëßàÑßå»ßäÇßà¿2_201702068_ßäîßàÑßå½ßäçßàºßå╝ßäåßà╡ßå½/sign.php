<?php 

/* 로그인 페이지에서 sign-up 버튼을 눌렀을 때 서버 간 통신에 관련된 PHP */

$PATH = "./data/id.json"; // id json 데이터 저장 경로

// validation check function
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function createAccount(){
    
    global $PATH;
    $id = $pw = "";

    if (isset($_POST["id"]) && isset($_POST["pw"])) { // post 형식으로 넘어왔을 때 validation check
        $id = test_input($_POST["id"]);
        $pw = test_input($_POST["pw"]);
    } else {
        echo "데이터 전송이 원할하지 않습니다."; // post 형식으로 넘어오지 않았을 때는 에러 메시지 전송
        exit;
    }

    if(is_file($PATH)){ // 파일이 존재할 때

        $json = file_get_contents($PATH);
        $jsonArr = json_decode($json, true); // jsonArr는 json 데이터을 가진 배열의 형태

        for ($i = 0; $i < sizeof($jsonArr); $i++) { // Json data 를 전부 탐색
            if($jsonArr[$i]["id"] === $id){
                echo "이미 아이디가 존재합니다."; // 이미 같은 아이디가 존재하므로 데이터를 저장하지 않고 에러 메시지 전송
                exit;
            }
        }

        // id와 pw 데이터를 가진 객체 생성 
        if(!isset($myObj)){
            $myObj = new stdClass();
        }
        $myObj->id = $id;
        $myObj->pw = $pw;

        array_push($jsonArr, $myObj); // 해당 객체를 jsonArr 배열에 push

        $myJSON = json_encode($jsonArr); // json_encode
        file_put_contents($PATH, $myJSON); // file 저장

        echo "회원 가입이 완료되었습니다.";
        exit;

    } else { // 파일이 존재하지 않을 때 

        // id와 pw 데이터를 가진 객체 생성 
        if(!isset($myObj)){
            $myObj = new stdClass();
        }
        $myObj->id = $id;
        $myObj->pw = $pw;

        $myObjArr = [$myObj]; // 배열 생성

        $myJSON = json_encode($myObjArr); // json_encode
        file_put_contents($PATH, $myJSON); // file 저장

        echo "회원 가입이 완료되었습니다.";
        exit;
    } 
}

createAccount();

?>