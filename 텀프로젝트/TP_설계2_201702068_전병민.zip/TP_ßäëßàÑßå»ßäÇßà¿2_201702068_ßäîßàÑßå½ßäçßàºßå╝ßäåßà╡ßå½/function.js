
/* 전역변수들 */

var whatSubject;

/* 과목 추가 버튼을 눌렀을 때, 과목 일정관리 상자가 생성되는 함수  */

document.getElementById("addSubject").addEventListener("click", addSubject);

function addSubject() {
    
    var yourTitle = prompt("과목의 이름이 무엇인가요?");
    
    // # 과목을 추가하기 전 과목의 이름을 설정
    // 1. 만약 아무것도 입력하지 않으면 에러 메시지 출력
    // 2. 취소할 시 아무런 행동도 하지 않음 
    // 3. 과목이름이 입력되면 페이지에 과목 상자가 생긴다.
    // 4. 이 과목 상자에는 과목 이름, 과목 삭제 버튼, 일정 추가 버튼이 있다.
    if(yourTitle === ""){

        alert("과목의 이름을 입력하지 않았습니다.")

    } else if(yourTitle !== null){
        
        /* title */
        var titleLink = document.createElement("a");
        titleLink.setAttribute("href", "subjectInfo.html"); // 과목 정보 페이지로 이동하는 링크 삽입

        var title = document.createTextNode(yourTitle); // textNode에 프롬프트를 이용하여 입력받은 과목 이름을 삽입
        titleLink.appendChild(title); // a는 프롬프트에서 입력받은 텍스트 노드를 가지게 됨
    
        var subjectTitle = document.createElement("h1"); 
        subjectTitle.appendChild(titleLink); // h1에 a 자식 추가

        var line = document.createElement("hr");
        
        var table = document.createElement("table");
        table.setAttribute("class", "taskContainer");

        /* 일정 추가 버튼 */
        var taskAddButton = document.createElement("button");
        var add = document.createTextNode("+");
        taskAddButton.appendChild(add);
        taskAddButton.setAttribute("class", "taskAddButton");
        taskAddButton.addEventListener("click", function(){ // 이 버튼을 클릭할 때, 팝업을 열고 whatSubject 변수에 클릭한 노드의 부모의 부모노드가 저장된다.
            openForm();
            whatSubject = this.parentElement.parentElement;
        })
    
        /* 과목 삭제 버튼 */
        var removeSubject = document.createElement("button");
        var remove = document.createTextNode("-");
        removeSubject.appendChild(remove);
        removeSubject.setAttribute("class", "removeSubjectButton");
        removeSubject.addEventListener("click", function(){

            /* 과목 삭제 버튼을 눌렀을 때, 섹션이 삭제되는 함수 */
            var isOK = confirm("정말 삭제하시겠습니까?");

            if(isOK){
                var subjectSection = document.getElementById("subjectSection");
                subjectSection.removeChild(this.parentElement.parentElement); 
                //subjectSection은 과목 상자가 존재하는 div이며 this의 부모의 부모가 과목상자이다. removeChild를 이용하여 이 과목상자를 삭제하였다.
            } 

            /* 과목 삭제 버튼을 눌렀을 때, 과목을 서버에 전송해서 해당 파일을 삭제해야 하는 함수 구현 예정 */

        })

        /* 두 버튼을 묶는 buttons */
        var buttons = document.createElement("div");
        buttons.appendChild(removeSubject);
        buttons.appendChild(taskAddButton);

        /* newContainer = 과목상자. 생성해둔 노드들을 과목상자의 자식으로 만들어주었다. */
        var newContainer = document.createElement("div");
        newContainer.appendChild(subjectTitle);
        newContainer.appendChild(line);
        newContainer.appendChild(table); // 테이블을 미리 생성해두고 일정을 추가할 때 테이블에 추가하였다.
        newContainer.appendChild(buttons);
        newContainer.setAttribute("class", "subjectContainer");

        var subjectSection = document.getElementById("subjectSection");
        subjectSection.appendChild(newContainer); // 서브젝트 섹션에 과목상자 추가

    }

}


/* 작업 추가 버튼을 눌렀을 때, 일정 추가를 위한 팝업 페이지 오픈되는 함수 */

function openForm() {
    document.getElementById("myForm").style.display = "block";
    document.getElementById("black_bg").style.display = "block";
    
}


/* 팝업 페이지에서 취소 버튼을 눌렀을 때 팝업을 닫는 함수 */

document.getElementById("cancelButtonInForm").addEventListener("click", closeForm);
function closeForm() {
    document.getElementById("myForm").style.display = "none";
    document.getElementById("black_bg").style.display = "none";
}  


/* 서버에 해당 데이터를 보내서 파일에 같은 task title이 있는 확인하고 저장하는 함수 */

document.getElementById("addTaskButtonInForm").addEventListener("click", checkFileTitle);
function checkFileTitle() {
    var taskTitle = document.getElementById("taskTitle");
    var keywords = document.getElementsByName("keyword");
    var flag = document.getElementById("flag");
    var deadline = document.getElementById("deadline");
    var keyword;
    
    for (let i = 0; i < keywords.length; i++) { // radio 항목 중 어떤 것이 선택되었는지 알기 위해서.
        if(keywords[i].checked) {
            keyword = keywords[i];
        }
    }
    
    // 데이터를 서버로 전송
    $.ajax({
        url:'addTask.php',
        type:'POST',
        data: {
            subject:whatSubject.firstChild.firstChild.firstChild.textContent, // 해당 과목 상자의 과목명을 알아야 올바른 경로에 파일을 저장할 수 있다.
            title:taskTitle.value,
            keyword:keyword.value,
            flag:flag.value,
            deadline:deadline.value
        },
        success:function(data){
            if(data == "SUCCESS"){

                addTask(taskTitle);
                // 실질적으로 화면에 일정을 추가하는 함수
                // 같은 일정 이름이 없다면 taskTitle(일정이름이 담긴 노드)을 파라미터로 넘김 

            } else if(data == "LOG_FAIL"){

                alert("로그인이 필요한 작업입니다."); // 로그인이 되어있지 않을 때

            } else {
                alert(data);
            }
        },
        error:function(){
            alert("서버와의 통신이 원할하지 않습니다.");
        } 
    })

    closeForm();
}



/* 팝업 페이지에서 작업 추가 버튼을 눌렀을 때 해당 과목에 일정을 추가하는 함수 */

// 과목 상자를 만들때 추가하였던 테이블에 생성되도록 구현하였다.

function addTask(data) {

    /************************** 여러가지 정렬을 할 수 있는 버튼 추가 구현 예정 *****************************/

    // 1. 첫번째 컬럼 : 체크박스
    var checkbox = document.createElement("input");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("class", "checkboxs");
    // 체크박스를 체크하면 css 속성을 바꾸 함수
    // 1. 체크되어 있으면 색상을 회색, 가운데 선을 긋는다.
    // 2. 체크되어 있지 않으면 색상과 선을 defalut 값을 가지게 한다.
    checkbox.addEventListener("click", function(){
        if(this.checked){
            this.setAttribute("checked", "true");
            this.parentElement.parentElement.childNodes[1].style.color = "grey";
            this.parentElement.parentElement.childNodes[1].style.textDecoration = "line-through";
        } else {
            this.setAttribute("checked", "false");
            this.parentElement.parentElement.childNodes[1].style.color = "black";
            this.parentElement.parentElement.childNodes[1].style.textDecoration = "none";
        }
    })
    var col1 = document.createElement("td");
    col1.setAttribute("class", "col1");
    col1.appendChild(checkbox);


    // 2. 두번째 컬럼 : 일정 이름
    var taskTitle = document.createTextNode(data.value);
    var col2 = document.createElement("td");
    col2.setAttribute("class", "col2");
    col2.appendChild(taskTitle);
    
    // 3. 세번째 컬럼 : 일정 삭제버튼
    var removeTask = document.createElement("input");
    removeTask.setAttribute("type", "button");
    removeTask.setAttribute("value", "삭제");
    removeTask.setAttribute("class", "removeTaskButton");
    /* 일정 삭제 버튼을 눌렀을 때, 일정이 삭제되는 함수 */
    removeTask.addEventListener("click", function(){
        var table = this.parentElement.parentElement.parentElement; // dom 구조를 활용하여 해당 과목상자에 있는 table을 변수에 담아주었다.
        var count = table.rows.length; // row의 개수
        for (let i = 0; i < count; i++) {
            if(table.rows[i].childNodes[1] == this.parentElement.parentElement.childNodes[1]){
                table.deleteRow(i); // table의 row를 돌면서 클릭한 자기자신의 일정 이름과 같으면 row를 삭제하였다.
                break;
            }
        }

        /**************** 서버에도 전송해서 파일에서 일정을 삭제해 주는 함수 구현예정 ********************/ 
    })
    var col3 = document.createElement("td");
    col3.setAttribute("class", "col3");
    col3.appendChild(removeTask);

    // 4. row 생성
    var row = document.createElement("tr");
    row.setAttribute("class", "rows");
    row.appendChild(col1);
    row.appendChild(col2);
    row.appendChild(col3);

    // 5. 최종적으로 과목상자에 있는 테이블에 row를 추가해주게 된다.
    whatSubject.childNodes[2].appendChild(row);
}



/*********************** 구현 예정인 함수들 **************************/

/* 과목 삭제 버튼을 눌렀을 때, 과목을 서버에 전송해서 해당 파일을 삭제하는 함수 */

/* 일정 삭제 버튼을 눌렀을 때, 일정을 서버에 전송해서 해당 일정을 삭제하는 함수 */

/* 세션에 저장되있는 id와 관련된 데이터를 파일에서 불러오는 함수 */

/* 일정 항목에 대한 여러가지 정렬을 구현 (중요도, 마감일, 시험/과제/강의 우선정렬 등등)*/